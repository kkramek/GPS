/*
 * main.c
 *
 *  Created on: 21 maj 2018
 *      Author: Grzegorz Szymczyk
 */
#include "u8g.h"
#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/atomic.h>
#include <avr/sleep.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ff.h"

#define VREF_MC 2.55		//Napiecie referencyjne mikrokontrolera zmierzone multimetrem
#define VREF_ACC 2.23		//Napiecie ze zrodla odniesienia zmierzone multimetrem
#define BITNUMBER 1024      //Rozdzielczosc przetwornika ADC
#define LICZBA_LINII 3
char *EkranPowitalny[LICZBA_LINII] = {	"   TERMOMETR","  ELEKTRYCZNY","  SMIW PROJEKT"};
char Tekst[10];
char czyZapis=0;
volatile unsigned char odb_flaga = 0;
#define AT_ILOSC_ZNAKOW 4//maksymalna d�ugo�� komendy wraz ze znakiem \n
#define AT_ILOSC_WZORCOW 2
const char wzorzec_START[]="TTT";
const char wzorzec_STOP[]="NNN";
char bufor_odb[AT_ILOSC_ZNAKOW + 1]; //bufor
volatile char at_odebrano_znakow = 0; //indeks znaku w tablicy bufora
volatile unsigned int usart_bufor_ind;
//Konfiguracja transmisji po USARTcie
void USART_Init(void)
{
	//definiowanie parametr�w transmisji za pomoc� makr zawartych w pliku
	#define BAUD 9600        		//9600bps standardowa pr�dkosc transmisji modu�u HC-05
	#include <util/setbaud.h> 		//linkowanie tego pliku musi by�//po zdefiniowaniu BAUD
	//ustawiamy obliczone przez makro warto�ci
	UBRRH = UBRRH_VALUE;
	UBRRL = UBRRL_VALUE;
	//Ustawiamy pozosta�e parametry modu� USART
	#if USE_2X
		UCSRA |=  (1<<U2X);
	#else
		UCSRA &= ~(1<<U2X);
 	#endif
	UCSRC = (1<<URSEL) | (1<<UCSZ1) | (1<<UCSZ0);
 	UCSRB = (1<<TXEN) | (1<<RXEN) | (1<<RXCIE);
 	DDRC = 0x42;
}
ISR(USART_RXC_vect) //przerwanie generowane po odebraniu bajtu
{
	static int bufor_odb_ind = 0;
	bufor_odb [bufor_odb_ind] = UDR;
	if (bufor_odb [bufor_odb_ind] == 0x00) { //Odebrano cala komende ze znakiem konca
		odb_flaga = 1;
		at_odebrano_znakow = bufor_odb_ind;
		bufor_odb_ind = 0;
	}
	else{									//Nie bylo jeszcze konca wiec dorzucamy kolejne znaki
		bufor_odb_ind++;
		if (bufor_odb_ind >= AT_ILOSC_ZNAKOW){
			bufor_odb_ind = 0;
		}
	}
}
ISR(USART_UDRE_vect){
	//przerwanie generowane, gdy bufor nadawania jest ju� pusty,
	 //odpowiedzialne za wys�anie wszystkich znak�w z tablicy usart_bufor[]
	if(Tekst[usart_bufor_ind]!= 0){
		UDR = Tekst[usart_bufor_ind++];
	}
	else{
		UCSRB &= ~(1<<UDRIE);
	}
}
void wyslij_wynik(void){
	//funkcja rozpoczyna wysy�anie, wysy�aj�c pierwszy znak znajduj�cy si�
	 //w tablicy usart_bufor[]. Pozosta�e wy�le funkcja przerwania,
	 //kt�ra zostanie wywo�ana automatycznie po wys�aniu ka�dego znaku.
	while (!(UCSRA & (1<<UDRE)));
	usart_bufor_ind = 0;
	UCSRB |= (1<<UDRIE);
}
void jakaKomenda(void){   //Jak zidentyfikuje komend� to
	if(strcmp(bufor_odb,wzorzec_START)==0){
		czyZapis=1;			//Rozpoczyna rejestracj�
		PORTC |= 0x40;
	}
	else if(strcmp(bufor_odb,wzorzec_STOP)==0){
		czyZapis=0;			//Ko�czy rejestracj�
		PORTC&=0x02;
	}
	odb_flaga=0;
}
//Czesc do wykonywania pomiaru napiecia przy uzyciu wdbudowanego przetwornika AC
ISR(ADC_vect)  //Funkcja obs�ugi przerwania wystarczy ze bedzie pusta
{}
void ADC_Init() //Konfiguracja ADC
{
	ADMUX=_BV(REFS1) | _BV(REFS0);    //Wewn�trzne nap. referencyjne, kana� 0, wyr�wnanie do prawej
	ADCSRA=_BV(ADEN) | _BV(ADIE) | _BV(ADPS2) | _BV(ADPS1) | _BV(ADPS0);    //W��cz ADC, przerwania, preskaler 128
}
int GetADC()
{
	set_sleep_mode(SLEEP_MODE_ADC);    //Tryb noise canceller
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {sleep_enable();};     //Odblokuj mo�liwo�� wej�cia w tryb sleep
	sleep_cpu();                       //Wejd� w tryb u�pienia
	sleep_disable();                   //Zablokuj mo�liwo�� wej�cia w tryb sleep
	return ADC;
}
//Czesc do obslugi wyswietlania
u8g_t u8g;
void OLED_Init(){//Konstruktor odpowiedni dla danego typu wy�wietlacza /sterownika wy�wietlacza
    u8g_InitSPI(&u8g, &u8g_dev_ssd1306_128x64_sw_spi, PN(1, 7), PN(1, 5), PN(1, 4), PN(1, 3), U8G_PIN_NONE);
}
void Rysuj(char *napis,int x, int y)
{
	u8g_SetFont(&u8g, u8g_font_fub17);
	u8g_DrawStr(&u8g, x, y, napis); //Tekst to wyswietlenia, gdzie: x i y oraz jaki char*
}
void RysujPowitanie(void) {
	u8g_SetFont(&u8g, u8g_font_6x13);
	u8g_DrawStr(&u8g,15,10,EkranPowitalny[0]);
	u8g_DrawStr(&u8g,15,30,EkranPowitalny[1]);
	u8g_DrawStr(&u8g,15,50,EkranPowitalny[2]);
}
//Czesc do zapisu na karcie pamieci
FATFS FatFs;
FIL Fil;
void write(char *napis, int ileZnakow)
{
	UINT bw1, bw2;
	f_mount(&FatFs, "", 0);
	if (f_open(&Fil, "Dane.txt", FA_WRITE | FA_OPEN_APPEND) == FR_OK) {	/* Otwiera plik do zapisu, dopisuje na koncu pliku */
		f_write(&Fil, napis, ileZnakow, &bw1);	/* Zapisuje znaki do pliku */
		f_write(&Fil, "\r\n", 2, &bw2);	/* Znaki powrotu karetki i nowej linii */
		f_close(&Fil);								/* Zamyka plik */
		if (bw1 == ileZnakow) {		//Jezeli zapis sie udal
			PORTC |= 0x02;	        //Zapala zielona diode
		}
	}
}
void BitToString(double temperatura){ //Konwertuje wartosc temperatury na tablice char
	int dlugosc;
	dtostrf(temperatura,0,1,Tekst);
	dlugosc=strlen(Tekst);
	if(czyZapis) write(Tekst, dlugosc);
	Tekst[dlugosc]=' ';
	Tekst[dlugosc+1]='C';
	Tekst[dlugosc+2]=13;
	Tekst[dlugosc+3]=10;
	Tekst[dlugosc+4]=0;
}
int main(void) //Glowna petla programu
{//Deklaracje i definicje zmiennych
    static int res;
    double wynik, R,suma;
    double A, B, C, t=0.0, R0;
    int i;
    A=0.0039083;
    B=-0.0000005775;
    C=-0.000000000004183;
    R0=100.0;
    //Inicjalizacje
    sei();
    ADC_Init();
    USART_Init();
    OLED_Init();
    u8g_FirstPage(&u8g); //Ekran powitalny
    do
    {
    	RysujPowitanie();
    } while (u8g_NextPage(&u8g));
    u8g_Delay(500);
    for(;;) //G��wna p�tla programu
    {
    	suma=0.0;
    	for(i=0;i<10;i++){ //Robimy 10 pomiar�w napi�cia
    		res=GetADC();  //Robimy pomiar
    		wynik=(res*VREF_MC)/BITNUMBER; //Przeliczamy bity na wartosc napiecia
    		suma=suma+wynik;
    	}
        wynik=suma/10.0; //Usredniamy
        if (wynik <2.4){                  //Kiedy jest rozwarty uklad (nie ma podpietego czujnika)
        	R=100.4/((VREF_ACC/wynik)-1); //Napi�cie na rezystancje
        	if (R<R0){
        		t=(R/R0-1)/(A+100*B);
        		for(i=0;i<3;i++){
        			t = t - (1 + A*t + B*t*t + C*t*t*t * (t - 100) - R/R0) / (A + 2*B*t - 300*C*t*t + 4*C*t*t*t);
        		}
        	}
        	else {
        		t = (-A + sqrt(A*A - 4*B*(1 - R / R0)))/(2*B);
        	}
        }
        else
        	t=999.9;
        BitToString(t);			//Double na tablice char plus znaczki
        if(odb_flaga) jakaKomenda();
        wyslij_wynik(); 		//Wysylamy do modulu blueetotha
        u8g_FirstPage(&u8g); 	//Wysylamy do wyswietlacza
        do
        {
        	Rysuj(Tekst,20,45);
        } while ( u8g_NextPage(&u8g) );
        PORTC&=0x40;             //Wylacza druga diode
        u8g_Delay(100);
    }
}
